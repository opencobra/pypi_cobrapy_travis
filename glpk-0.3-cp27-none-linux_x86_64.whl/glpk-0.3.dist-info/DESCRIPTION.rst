The PyGLPK module gives one access to the functionality
of the GNU Linear Programming Kit.  


